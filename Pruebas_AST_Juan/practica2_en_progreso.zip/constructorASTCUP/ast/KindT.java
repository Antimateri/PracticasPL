package ast;

public enum KindT {
    INT, BOOL, COMP, POINTER, STRUCT
}
