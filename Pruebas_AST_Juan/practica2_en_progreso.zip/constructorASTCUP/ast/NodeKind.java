package ast;

public enum NodeKind {
  EXPRESSION, INSTRUCTION, IDEN, DECLARATION, TYPE
}
