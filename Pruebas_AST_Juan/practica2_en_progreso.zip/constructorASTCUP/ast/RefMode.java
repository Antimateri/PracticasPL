package ast;

public enum RefMode {
    REF, VALUE
}
