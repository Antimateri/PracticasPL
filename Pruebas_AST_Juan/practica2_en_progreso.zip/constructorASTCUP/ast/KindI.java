package ast;

public enum KindI {
  IF,WHILE,BLOQUE,ASIG,IFELSE, RETURN, PRINT, READ
}