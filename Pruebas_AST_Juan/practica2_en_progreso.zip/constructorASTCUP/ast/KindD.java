package ast;

public enum KindD {
    VAR, TYPE, FUN, PROC, STRUCT
}
